package Academy;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import pageObjects.FlightSearch;
import resources.base;

public class HomePage extends base{
	public WebDriver driver;
	
	 public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();
		 

	}
	@Test()

	public void basePageNavigation() throws IOException, InterruptedException
	{


		// creating object to that class and invoke methods of it
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
// 2). Click on the ​flights​ link and select ​round​ trip option
		LandingPage l=new LandingPage(driver);
		l.getroundTripButton().click();
		l.getFromPlace().sendKeys("NEW");
		Thread.sleep(4000);
 
//3). Select ​From:​ Delhi and ​To: ​Mumbai
		
		l.getFromPlace().sendKeys(Keys.ENTER);
		l.getToPlace().sendKeys("MUM");
		Thread.sleep(4000);
		l.getToPlace().sendKeys(Keys.ENTER);
		
		l.getFromDate().click();
//4). Select ​departure date as today’s date​ and ​return date:​ 10 days after today’s date.		
		
		 DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		    Calendar cal = Calendar.getInstance();
		    cal.setTime(new Date());
		    cal.add(Calendar.DATE, 10);
		    String newDate = dateFormat.format(cal.getTime());
		    
		 l.getReturnDate().clear();
		 l.getReturnDate().sendKeys(newDate);
		 
		 l.getReturnDate().sendKeys(Keys.TAB);
		 
//5) Click on the button “​Search Flights”.		 
		 l.getSearchButton().click();
		 
		 
	
		 FlightSearch fs = new FlightSearch(driver);
		 
		 List<Integer> deptprices = fs.getDeptPriceValues();
		 int count1 = 0;
		 int count2 = 0;
		 
		 for(Integer dp : deptprices) {
		 if(dp<5000) {
			 count1++;
		 } }
		 
		 List<Integer> returnprices = fs.getReturnPriceValues();
		 for (Integer rp : returnprices) {
			 
			 if(rp<7000) {
				 count2++;
			 }
		 }
//6) Print total number of records of “​Departing Flights”​ and ​Return Flights ​where price of departing flight is < ​Rs. 5000​ and price of return flight < ​Rs. 7000
	  System.out.println("Number of departing flights with price less than 5k: " + count1);
	  System.out.println("Number of returning flights with price less than 7k: " + count2);
	  
	  
		 log.info("Flights are displayed");
	  int boxCount = fs.getchckBoxes().size();
	  
	  for(int i=0; i<boxCount; i++) {
		  
		  fs.getchckBoxes().get(i).click();
	  }
	  
	  List<Integer> allFlights = fs.getAllPriceValues();
	  int pricelessthanSeven = 0;
      
	  for(Integer prices : allFlights) 
	  if(prices<7000) {
		  
		  pricelessthanSeven++;
	  }
//7) Select filter ​“Non Stop” ​and​ “1 Stop”​ and Print total number of records of “Departing Flights” and Return Flights where price is less than ​Rs. 7000.	  
	    System.out.println("total number of Departing and Return flights where price is less than ​7000: " + pricelessthanSeven);
	  
//8) Select ​2n​d​ departing Flight​ and ​5t​h​ return flight​
	     fs.getDeptFlight().click();
	     fs.getReturnFlight().click();
	     
	     
	     int deptPrice = fs.getDeptFlightPrice();
	     int retPrice = fs.getReturnFlightPrice();

	     int totalPrice = deptPrice + retPrice;
	     
	     System.out.println("total price " + totalPrice);
	      int  actualPrice =  fs.getTotalPrice();
	      System.out.println(" act price " + actualPrice);
	      
//9) Validate if the flight booking price is sum of departing flight and return flight 	      
	     Assert.assertEquals(totalPrice, actualPrice);
	     
	     
     log.info("Price matches");
	  
	  
	  
		
	    
	}

		 
		
		
	

	@AfterTest
	public void teardown()
	{
		
		driver.close();
	
		
	}
	}
	
	









