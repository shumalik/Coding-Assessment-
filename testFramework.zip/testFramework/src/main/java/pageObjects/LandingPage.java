package pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

	
	public WebDriver driver;
	
	By roundTrip = By.id("RoundTrip");
	By fromPlace = By.id("FromTag");
	By toPlace =   By.id("ToTag");
	By fromDate =  By.cssSelector(".ui-state-default.ui-state-highlight.ui-state-active ");
	By returnDate = By.id("ReturnDate");
	By searchBtn = By.id("SearchBtn");
	

	
		
	
	public LandingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		
		this.driver=driver;
		
	}


	
	public WebElement getroundTripButton()
	{
		return driver.findElement(roundTrip);
	}
	
	public WebElement getFromPlace()
	{
		return driver.findElement(fromPlace);
	}
	
	public WebElement getToPlace()
	{
		return driver.findElement(toPlace);
	}
	public WebElement getFromDate()
	{
		return driver.findElement(fromDate);
	}
	public WebElement getReturnDate()
	{
		return driver.findElement(returnDate);
	}
	public WebElement getSearchButton()
	{
		return driver.findElement(searchBtn);
	}
	

	
	
	
}
