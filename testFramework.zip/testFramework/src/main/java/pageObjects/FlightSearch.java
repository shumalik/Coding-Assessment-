package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FlightSearch {

	
	public WebDriver driver;
	
	
	By deptFlightPrices = By.xpath("//div[@data-test-attrib='onward-view']//span[@class='flex-inline flex-right']/preceding-sibling::p");
    By returnFlightPrices = By.xpath("//div[@data-test-attrib='return-view']//span[@class='flex-inline flex-right']/preceding-sibling::p");

    By stopschckBoxes = By.xpath("(//div[@class='pt-3'])[1]//div[@class='flex flex-start p-relative flex-middle']//span");
	By allStopsFlightsPrices = By.xpath("//span[@class='flex-inline flex-right']/preceding-sibling::p");
	
	
	By secondDepartureFlight = By.xpath("//div[@data-test-attrib='onward-view']/div/div[2]");
	By fifthReturnFlight = By.xpath("//div[@data-test-attrib='return-view']/div/div[5]");
	
	
	By deptFlightPrice = By.xpath("//div[@data-test-attrib='onward-view']/div/div[2]//span[@class='flex-inline flex-right']/preceding-sibling::p");
	By returnFlightPrice = By.xpath("//div[@data-test-attrib='return-view']/div/div[5]//span[@class='flex-inline flex-right']/preceding-sibling::p");
	By totalPrice = By.xpath("//div[@class='flex flex-bottom flex-right']//span");
	public FlightSearch(WebDriver driver) {
		// TODO Auto-generated constructor stub
		
		this.driver=driver;
		
	}


public List<WebElement> getDeptPrices()
{
	return driver.findElements(deptFlightPrices);
}

public List<WebElement> getReturnPrices()
{
	return driver.findElements(returnFlightPrices);
}

public List<Integer> getDeptPriceValues() {
	
	List<Integer> list = new ArrayList<Integer>();
	int count =  getDeptPrices().size();
   int values=0;
	for(int i =1; i<count; i++) {
		
		String prices = getDeptPrices().get(i).getText().split("₹")[1];
		values = Integer.parseInt(prices.replace(",", ""));
		list.add(values);
}


	return list;
}
public List<Integer> getReturnPriceValues() {
	
	List<Integer> list = new ArrayList<Integer>();
	
	int count =  getReturnPrices().size();
	int values = 0;
	for(int i =1; i<count; i++) {
		
		String  prices =   getReturnPrices().get(i).getText().split("₹")[1];
		values = Integer.parseInt(prices.replace(",", ""));
		list.add(values);
		
}

 return list;
}

public List<WebElement> getchckBoxes()

{
	return driver.findElements(stopschckBoxes);
}
public List<WebElement> getAllPrices()
{
	return driver.findElements(allStopsFlightsPrices);
}

public List<Integer> getAllPriceValues() {
	
	List<Integer> list = new ArrayList<Integer>();
	int count =  getAllPrices().size();
	int values = 0;
	
	for(int i =1; i<count; i++) {
		
		 String prices =   getAllPrices().get(i).getText().split("₹")[1];
		 values = Integer.parseInt(prices.replace(",", ""));
			list.add(values);
		 
		
}

	return list;
}

public WebElement getDeptFlight() {
	
	return driver.findElement(secondDepartureFlight);
}
public WebElement getReturnFlight() {
	
	return driver.findElement(fifthReturnFlight);
}

public int getReturnFlightPrice() {
	
	String price =  driver.findElement(returnFlightPrice).getText();
	
	String priceVal = price.split("₹")[1];
	return Integer.parseInt(priceVal.replace(",",""));
}

public int getDeptFlightPrice() {
	
	String price =  driver.findElement(deptFlightPrice).getText();
	
	String priceVal = price.split("₹")[1];
	return Integer.parseInt(priceVal.replace(",", ""));
}

public int getTotalPrice() {
	
	String price =  driver.findElement(totalPrice).getText();
	String priceVal = price.split("₹")[1];
	return Integer.parseInt(priceVal.replace(",", ""));
	//return Integer.parseInt(priceVal);
}

}
