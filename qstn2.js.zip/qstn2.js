//2. Given is a string having n words In it: ex: “​Bangalore Is in India​” :
A- Write a program to print the words which have repeated characters. ​Ex​ ​o/p:​ ​Bangalore,
India -
B- Print the name and count of repeating characters in the words found in above steps:
Ex​ ​O/p : Bangalore – a (2) India – I(2)



function duplicate(str){

    let arr = str.split(' ');
  console.log(arr);
  let obj= {};
   for(let value of arr){

    if(hasDuplicate(value).includes(2)){

        console.log(value + '-' + hasDuplicate(value).join(''));

 
   }

}
}
function hasDuplicate(str){

    let obj = {};
   let arr = [];
 
    for(let value of str.toLowerCase().split('')){
        obj[value] = obj[value] + 1 || 1;
    }

        for( let key in obj){
        if(obj[key]>1){
    
    arr.push(key,obj[key]);
        }
        }
     return arr;

}

console.log(duplicate('Bangalore is in India'));
