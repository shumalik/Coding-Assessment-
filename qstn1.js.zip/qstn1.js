// 1. Write a program to find out 6 digit numbers between (100000, 300000) which when multiplied by 2 gives all the same digits as in actual numbers- Ex. Let’s say the number is 123456 ​and now it is multiplied by 2 and it generates 341265 (contains all digits which are in actual number)


function repeated(){

   let mul = 0;

     for(let i=100000; i<=300000; i++){
 
         mul = i * 2;
         _i = +(i.toString().split('').sort().join(''));
         let num = +(mul.toString().split('').sort().join(''));
         
        
      
         if(num===_i){


            console.log(i);
        }
   
     }


    
}


console.log(repeated());